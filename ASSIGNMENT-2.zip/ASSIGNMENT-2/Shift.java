import java.lang.*;
class Shift{
public static void main(String args[]){
int x=5;
System.out.println("x>>>3:"+(x>>>3));
System.out.println("x<<2:"+(x<<2));
}
}