import java.lang.*;
class Cube{
public static void main(String args[]){
int side=5;
int l=2;
int b=3;
int h=4;
int cube=side*side*side;
int cuboid =l*b*h;
System.out.println("The area of the cube is :"+cube);
System.out.println("The area of the cuboid is:"+cuboid);
}
}