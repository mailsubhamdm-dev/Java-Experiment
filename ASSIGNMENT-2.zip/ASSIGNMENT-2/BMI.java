import java.lang.*;
class BMI{
public static void main(String args[]){
double weight=25.00;
double height=23.00;
double BMI=weight/(height*height);
System.out.println("The body mass index will be:"+BMI);
}
}