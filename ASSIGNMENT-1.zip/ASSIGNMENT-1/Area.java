import java.lang.*;
class Area
{
public static void main(String args[])
{
int h=3;
int l=4;
int b=5;
int rect=l*b;
int square=l*l;
int cube=l*l*l;
System.out.println("The area of the rectangle is :"+rect);
System.out.println("The area of the square is :"+square);
System.out.println("The area of the cube is :"+cube);
}
}