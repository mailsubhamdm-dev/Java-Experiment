import java.lang.*;
class Swap
{
public static void main(String args[])
{
int a=5;
int b=3;
int temp=a;
    a=b;
    b=temp;
System.out.println("After Swapping:");
System.out.println("Swapping a is:"+a);
System.out.println("SWapping b is:"+b);
}
}