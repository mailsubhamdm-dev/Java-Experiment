import java.lang.*;
class Temp
{
public static void main(String args[])
{
int c=5;
int f=32+9*c/5;
System.out.println("Farhenheit will be : "+f);
}
}