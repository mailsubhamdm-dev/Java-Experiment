import java.util.Scanner;
class A5Q1{
public static void main(String args[]){
int i,j;
for(i=0;i<=5;i++){
for(j=1;j<=5-i;j++){
System.out.print(j+"\t");
}
System.out.println();
}
}
}